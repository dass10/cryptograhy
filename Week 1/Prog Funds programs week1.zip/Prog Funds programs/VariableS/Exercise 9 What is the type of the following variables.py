# Author name: Shweta Das
# Date: 21 August 2021
# Quick Description: type of the following variables-






a = "2"  <-- This is string

b = 4.3  <-- This is float

c = 6    <-- This is int 

d = 'abc' <-- This is string

# Author name: Shweta Das
# Date: 22 August 2021
# Quick Description: Input and Processing statements 




name = input(" Hi,What is your name?")
#age
print("Hi,", name)
age = input (" What is your age?")
print("age,",age)
#occupation
occupation = input("What is your occupation?")
print("occupation",occupation)

input("\n\n Press the enter key to exit.")

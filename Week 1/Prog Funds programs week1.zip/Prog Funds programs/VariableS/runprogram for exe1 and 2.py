Python 3.9.6 (tags/v3.9.6:db3ff76, Jun 28 2021, 15:26:21) [MSC v.1929 64 bit (AMD64)] on win32
Type "help", "copyright", "credits" or "license()" for more information.
>>> 
= RESTART: C:/Users/shwet/OneDrive - Unitec NZ/Desktop/NZDCS/HTCS6702 - Cryptography/Soheil's class/Prog Funds programs/VariableS/Exercise1.py
Dear Seminar Participants,
>>> 
= RESTART: C:/Users/shwet/OneDrive - Unitec NZ/Desktop/NZDCS/HTCS6702 - Cryptography/Soheil's class/Prog Funds programs/VariableS/Exercise1.py
Dear seminar Participants,

Thank you for taking part in the upcoming seminar on 
“Web Programming”.

The seminar will begin each day at 10:30 am with lunch and will end at 4 pm after evening tea each day. 
Registration starts 10 am.
Best Wishes,
Seminar Organizer

>>> 
= RESTART: C:/Users/shwet/OneDrive - Unitec NZ/Desktop/NZDCS/HTCS6702 - Cryptography/Soheil's class/Prog Funds programs/VariableS/Exercise1.py
Dear seminar Participants,

Thank you for taking part in the upcoming seminar on 
“Web Programming”.

The seminar will begin each day at 10:30 am with lunch and will end at 4 pm after evening tea each day. 
Registration starts 10 am.
Best Wishes,
Seminar Organizer

>>> salary = 53400
>>> tax = salary * 0.125
>>> somestring = "The amount of tax to pay: "
>>> print(somestring, tax)
The amount of tax to pay:  6675.0
>>> interest = salary * 0.04
>>> print("Interest from saving my salary into a bank",interest)
Interest from saving my salary into a bank 2136.0
>>> 
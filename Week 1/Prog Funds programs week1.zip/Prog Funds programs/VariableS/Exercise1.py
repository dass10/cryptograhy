# Author name: Shweta Das
# Date: 20 August 2021
# Quick Description: Print Statement. 




#only to use print command for multiple line

print("""Dear seminar Participants,

Thank you for taking part in the upcoming seminar on 
“Web Programming”.

The seminar will begin each day at 10:30 am with lunch and will end at 4 pm after evening tea each day. 
Registration starts 10 am.
Best Wishes,
Seminar Organizer
""")

       

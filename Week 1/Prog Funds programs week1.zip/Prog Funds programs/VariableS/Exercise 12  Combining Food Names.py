# Author name: Shweta Das
# Date: 20 August 2021
# Quick Description: Combining Food entry program




# first favorite food

food1 = input("Please enter your favourite food:")


print(food1)
# second favorite food

food2 = input("Please enter another favourite food:")


print(food2)

print("")

newfood = food1+food2


print("newfood:",newfood)


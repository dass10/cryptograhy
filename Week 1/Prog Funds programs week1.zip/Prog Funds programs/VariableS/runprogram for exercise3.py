Python 3.9.6 (tags/v3.9.6:db3ff76, Jun 28 2021, 15:26:21) [MSC v.1929 64 bit (AMD64)] on win32
Type "help", "copyright", "credits" or "license()" for more information.
>>> print("If a 2000 pound pregnant hippo gives birth to a 100 pound calf,")
If a 2000 pound pregnant hippo gives birth to a 100 pound calf,
>>> print("but then eats 50 pounds of food, how much does she weigh?")
but then eats 50 pounds of food, how much does she weigh?
>>> input("Press the enter key to find out.")
Press the enter key to find out.
''
>>> print("2000 - 100 + 50 =", 2000 - 100 + 50)
2000 - 100 + 50 = 1950
>>> print("\n if an adventurer returns from a successful quest and buys each of ")

 if an adventurer returns from a successful quest and buys each of 
>>> print("6 companies 3 bottles of ale, howmany bottles are purchased?")
6 companies 3 bottles of ale, howmany bottles are purchased?
>>> input("Press the enter key to find out.")
Press the enter key to find out.
''
>>> print("6 * 3 =", 6 * 3)
6 * 3 = 18
>>> print("\n if a restaurant check comes to 19 dollars wtih tip,and you and")

 if a restaurant check comes to 19 dollars wtih tip,and you and
>>> print("your friends split it evenly 4 ways,how much do you each throw in?)
      
SyntaxError: EOL while scanning string literal
>>> print("your friends split it evenly 4 ways, how much do you each throw in?")
your friends split it evenly 4 ways, how much do you each throw in?
>>> input("Press the enter key to find out.")
Press the enter key to find out.
''
>>> print("19 / 4 =", 19 / 4)
19 / 4 = 4.75
>>> print("/n if a group of 4 pirates finds a chest full of 107 gold coins, and ")
/n if a group of 4 pirates finds a chest full of 107 gold coins, and 
>>>  print("\n if a group of 4 pirates finds a chest full of 107 gold coins, and ")
 
SyntaxError: unexpected indent
>>> print("\nIf a group of 4 pirates finds a chest full of 107 gold coins, and")

If a group of 4 pirates finds a chest full of 107 gold coins, and
>>> print("they divide the booty evenly, how many whole coins does each get?")
they divide the booty evenly, how many whole coins does each get?
>>> input("Press the enter key to find out.")
Press the enter key to find out.
''
>>> print("107 // 4 =", 107 // 4)
107 // 4 = 26
>>> 
# Author name: Shweta Das
# Date: 21 August 2021
# Quick Description: Variable's type 





number = input("Enter a number:")

number = int(number) 

print(number)

result = number * 3;

print(result)

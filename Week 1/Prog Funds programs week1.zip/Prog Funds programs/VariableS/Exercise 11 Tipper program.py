
# Author name: Shweta Das
# Date: 21 August 2021
# Quick Description: Tipper program





input1 = input("Please enter bill amount:")
tip15 = float(input1)*0.15
print("")
print("tip15",tip15)

tip20 = float(input1)*0.20
print("")
print("tip20",tip20)




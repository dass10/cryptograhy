# Author name: Shweta Das
# Date: 22 August 2021
# Quick Description: Salary program


salary = 53400
tax = salary * 0.125
somestring = "The amount of tax to pay: "
print("somestring, tax")

interest = salary * 0.04
print("interest from saving my salary into a bank", interest)

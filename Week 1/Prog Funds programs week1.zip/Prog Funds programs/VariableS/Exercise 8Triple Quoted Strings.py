# Author name: Shweta Das
# Date: 21 August 2021
# Quick Description: Triple Quoted Strings



age = input("What is your age")

age = int(age)
# age + 1 It is adding another year with the current age
age = age + 1

print("you will be", age, "next year")

futureAge = age + 9

print("you will be", futureAge, "in 10 years")


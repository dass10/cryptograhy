Python 3.9.6 (tags/v3.9.6:db3ff76, Jun 28 2021, 15:26:21) [MSC v.1929 64 bit (AMD64)] on win32
Type "help", "copyright", "credits" or "license()" for more information.
>>> 21 * (366+41)
8547
>>> 33 * 4 *2.5 * 6
1980.0
>>> 1+29+33+40*(11+2)
583
>>> the remainder of 10/4
SyntaxError: invalid syntax
>>> 10/4
2.5
>>> 4/2/3
0.6666666666666666
>>> 
# Author name: Shweta Das
# Date: 18 August 2021
# Quick Description: find the average  program





# first number

num1 = input(" What is the first number?")
num1 = int(num1)

print(num1)
# second number

num2 = input(" What is the second number?")
num2 = int(num2)

print(num2)

# calculate average of those numbers
avg = (num1 + num2) / 2

# print average value
print('The average of numbers = %0.2f' %avg)

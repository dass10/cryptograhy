# Author name: Shweta Das
# Date: 22 August 2021
# Quick Description: Cost Calculate program






input1 = input("How much is your weekly rent?:")
input1 = float(input1)

print(input1)

input2 = input("How much do you pay for bus fare (weekly)?:")
input2 = float(input2)
print(input2)

input3 = input("How much did you spend on grocery last week?:")
input3 = float(input3)
print(input3)

print ("")

totalcost = (input1+input2+input3)



print("totalcost",totalcost)

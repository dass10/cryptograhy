# Author name: Shweta Das
# Date: 18th August 2021
# Quick Description: Triple Quoted Strings






print("Haunted House")
print("=============")
print("Game Over")

#""" for multiple lines
print ("""
        ____________________
        /                   \\
       /                     \\
       |  x             x     |
       |                     |
       |                     |
       |                     |
       |       _______       |
       |      /       \      |
       \                     /
        \___________________/       """)


# Author name: Shweta Das
# Date: 20 August 2021
# Quick Description: Quotes in Quotes



print("Haunted House")
print("=============")

print("Game Over")
print('© 2021, Unitec New Zealand 'ISCG5420 Programing Fundamentals'-SHWETA DAS')
print("Press the enter key to exit the fame")
input()


# Author name: Shweta Das
# Date: 16 August 2021
# Quick Description: Haunted House Game. 




print("Haunted House")
print("=============")
print("Game Over")
print("Press the enter key to exit the game")
input()


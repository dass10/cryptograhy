# Author name: Shweta Das 
# Date: 21 August 2021
# Quick Description: Exercise 1—Part 2—First Program



print("Game Over")
print("Press the enter key to exit the game")


Python 3.9.6 (tags/v3.9.6:db3ff76, Jun 28 2021, 15:26:21) [MSC v.1929 64 bit (AMD64)] on win32
Type "help", "copyright", "credits" or "license()" for more information.
>>> print ("Game Over")
Game Over
>>> print "Game over"
SyntaxError: Missing parentheses in call to 'print'. Did you mean print("Game over")?
>>> print(Game Over)
SyntaxError: invalid syntax
>>> 
= RESTART: C:/Users/shwet/OneDrive - Unitec NZ/Desktop/NZDCS/HTCS6702 - Cryptography/Soheil's class/Prog Funds programs/Day1/Exercise1.py
Game Over
Press the enter key to exit the game
>>> 
========================== RESTART: C:/Users/shwet/OneDrive - Unitec NZ/Desktop/NZDCS/HTCS6702 - Cryptography/Soheil's class/Prog Funds programs/Day1/Exercise2.py =========================
****************
***** SHWETA *****
****************
>>> 
= RESTART: C:/Users/shwet/OneDrive - Unitec NZ/Desktop/NZDCS/HTCS6702 - Cryptography/Soheil's class/Prog Funds programs/Day1/Exercise3.py
Haunted House
=============
Game Over
Press the enter key to exit the game

= RESTART: C:/Users/shwet/OneDrive - Unitec NZ/Desktop/NZDCS/HTCS6702 - Cryptography/Soheil's class/Prog Funds programs/Day1/Exercise7.py
Haunted House
=============
Game Over
© 2021, Unitec New Zealand "ISCG5420 Programing Fundamentals"-SHWETA DAS
Press the enter key to exit the fame

= RESTART: C:/Users/shwet/OneDrive - Unitec NZ/Desktop/NZDCS/HTCS6702 - Cryptography/Soheil's class/Prog Funds programs/Day1/Exercise7.py
Haunted House
=============
Game Over
© 2021, Unitec New Zealand 'ISCG5420 Programing Fundamentals'-SHWETA DAS
Press the enter key to exit the fame

= RESTART: C:/Users/shwet/OneDrive - Unitec NZ/Desktop/NZDCS/HTCS6702 - Cryptography/Soheil's class/Prog Funds programs/Day1/Exercise5.py
Haunted House
=============
Game Over



© 2021, Unitec New Zealand "ISCG5420 Programing Fundamentals"-SHWETA DAS
Press the enter key to exit the fame

= RESTART: C:/Users/shwet/OneDrive - Unitec NZ/Desktop/NZDCS/HTCS6702 - Cryptography/Soheil's class/Prog Funds programs/Day1/Exercise5.py
Haunted House
=============
Game Over
		© 2021, Unitec New Zealand 'ISCG5420 Programing Fundamentals'-SHWETA DAS
Press the enter key to exit the Game

= RESTART: C:/Users/shwet/OneDrive - Unitec NZ/Desktop/NZDCS/HTCS6702 - Cryptography/Soheil's class/Prog Funds programs/Day1/Exercise5.py
Haunted House
=============
Game Over
		© 2021, Unitec New Zealand  'ISCG5420 Programing Fundamentals'-SHWETA DAS
Press the enter key to exit the Game

= RESTART: C:/Users/shwet/OneDrive - Unitec NZ/Desktop/NZDCS/HTCS6702 - Cryptography/Soheil's class/Prog Funds programs/Day1/Exercise6.py
Haunted House
=============
Game Over

        ____________________
        /                   \
       /                     \
       |  x             x     |
       |                     |
       |                     |
       |                     |
       |       _______       |
       |      /       \      |
       \                     /
        \___________________/       
>>> 
= RESTART: C:/Users/shwet/OneDrive - Unitec NZ/Desktop/NZDCS/HTCS6702 - Cryptography/Soheil's class/Prog Funds programs/Day1/Exercise6.py
Haunted House
=============
Game Over
Traceback (most recent call last):
  File "C:/Users/shwet/OneDrive - Unitec NZ/Desktop/NZDCS/HTCS6702 - Cryptography/Soheil's class/Prog Funds programs/Day1/Exercise6.py", line 5, in <module>
    prnt ("""
NameError: name 'prnt' is not defined
>>> 
= RESTART: C:/Users/shwet/OneDrive - Unitec NZ/Desktop/NZDCS/HTCS6702 - Cryptography/Soheil's class/Prog Funds programs/Day1/Exercise6.py
Haunted House
=============
Game Over
Traceback (most recent call last):
  File "C:/Users/shwet/OneDrive - Unitec NZ/Desktop/NZDCS/HTCS6702 - Cryptography/Soheil's class/Prog Funds programs/Day1/Exercise6.py", line 5, in <module>
    Print ("""
NameError: name 'Print' is not defined
>>> 
= RESTART: C:/Users/shwet/OneDrive - Unitec NZ/Desktop/NZDCS/HTCS6702 - Cryptography/Soheil's class/Prog Funds programs/Day1/Exercise6.py
Haunted House
=============
Game Over

        ____________________
        /                   \
       /                     \
       |  x             x     |
       |                     |
       |                     |
       |                     |
       |       _______       |
       |      /       \      |
       \                     /
        \___________________/       
>>> 
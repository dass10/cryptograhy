# Author name: Shweta Das
# Date: 16 August 2021
# Quick Description: Escape Sequences



print("Haunted House")
print("=============")

print("Game Over")

#\t is for tab
print("\t\t© 2021, Unitec New Zealand  \'ISCG5420 Programing Fundamentals\'-SHWETA DAS")
print("Press the enter key to exit the Game")
input()

